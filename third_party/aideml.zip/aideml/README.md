# AIDE: Forked

The work is based on  `AIDE` agent from
the [AIDE: AI-Driven Exploration in the Space of Code](https://arxiv.org/abs/2502.13138). In our experiments
[MLE-bench: Evaluating Machine Learning Agents on Machine Learning Engineering](https://arxiv.org/abs/2410.07095)
version of `AIDE` is used.

## ⚙️ Setup

Refer the [Agent K documentation](../../agentdocs/docs/index.md) for setup and run guidelines.

### 📚 Running from RAG database 

We collected high-quality discussions and notebooks from the **past 24 Kaggle competitions** that began in or after *
*2021**.  
These documents were pre-processed into structured entries containing:

- Notebook summaries
- Technical discussions

```text
📁 ./path/to/collected_data
  ├── 📁 <competition name>
  │   ├── 📁 notebook_summaries
  │   │   ├── 📄 summary1.txt
  │   │   ├── 📄 summary2.txt
  │   ├── 📁 technical_reports
  │   │   ├── 📄 tech_report1.txt
  │   │   └── 📄 tech_report2.txt
```

---

#### 🛠️ Creating the RAG Database

Run the following command to populate the RAG database:

```bash
python aide/utils/db_faiss.py --populate --data_path <path/to/collected_data>
```