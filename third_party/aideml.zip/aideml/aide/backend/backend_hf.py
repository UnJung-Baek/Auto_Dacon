"""Backend for Huggingface API"""
import json
import logging
import os
import time
from datetime import datetime

import openai
from funcy import notnone, once, select_values
from huggingface_hub import (
    ChatCompletionOutput,
    ChatCompletionOutputComplete,
    ChatCompletionOutputMessage,
    ChatCompletionOutputUsage,
    InferenceClient,
)
from requests import HTTPError
from requests.exceptions import ProxyError
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_fixed,
)

from aide.backend.utils import (
    FunctionSpec,
    OutputType,
    backoff_create, opt_messages_to_list, fix_json_string, check_for_anomaly, LLMRetryManager, human_view,
)

logger = logging.getLogger("aide")

_client: InferenceClient = None  # type: ignore

OPENAI_TIMEOUT_EXCEPTIONS = (
    openai.RateLimitError,
    openai.APIConnectionError,
    openai.APITimeoutError,
    openai.InternalServerError,
)

retry_manager = LLMRetryManager()


@once
def _setup_hf_client():
    global _client
    _client = InferenceClient(
        api_key=os.environ["HF_TOKEN"],
        headers={"x-use-cache": "false"},
    )


def get_llm_connection_elapsed_time() -> int:
    return retry_manager.elapsed_time


def reset_llm_connection_elapsed_time() -> None:
    retry_manager.reset_elapsed_time()


@retry(
    stop=stop_after_attempt(30),
    wait=wait_fixed(5),
    retry=retry_if_exception_type(
        (openai.APIConnectionError, HTTPError, ProxyError)
    ),
    before_sleep=retry_manager.custom_before_sleep
)
def aux_llm_query(
        messages,
        **kwargs,
):
    response = _client.chat.completions.create(
        messages=messages,
        max_tokens=3000,
        **kwargs
    )
    raw_output_text = response.choices[0].message.content.strip()

    human_supervise = os.getenv("HUMAN_SUPERVISE", False)
    if human_supervise in ["0", "False", "false"]:
        human_supervise = False

    if human_supervise:
        parsed_response = human_view(raw_output_text, aux_llm_query, messages, **kwargs)
        resp_message = ChatCompletionOutputMessage(content=parsed_response, role="assistant")
        choices = [ChatCompletionOutputComplete(finish_reason="stop", index=0, message=resp_message)]
        response = ChatCompletionOutput(
            id='human',
            choices=choices,
            created=int(time.time()),
            model=kwargs.get('model'),
            system_fingerprint="",
            usage=ChatCompletionOutputUsage(completion_tokens=0, prompt_tokens=0, total_tokens=0)
        )
    return response


@retry(
    stop=stop_after_attempt(30),
    wait=wait_fixed(5),
    retry=retry_if_exception_type(
        (openai.APIConnectionError, HTTPError, ProxyError)
    ),
    before_sleep=retry_manager.custom_before_sleep
)
def json_fix_query(messages: list, error: Exception, filtered_kwargs) -> str:
    fix_prompt = (
        f"Failed to decode the following JSON response {error}:\n\n"
        f"Please fix the JSON format and return a valid JSON response."
    )

    # Send this fix request to the LLM to ask for corrections
    messages.append({"role": "user", "content": fix_prompt})

    completion = backoff_create(
        aux_llm_query,
        OPENAI_TIMEOUT_EXCEPTIONS,
        messages=messages,
        **filtered_kwargs,
    )

    choice = completion.choices[0]
    return choice.message.content


def query(
        system_message: str | None,
        user_message: str | None,
        func_spec: FunctionSpec | None = None,
        convert_system_to_user: bool = False,
        max_retries=10,
        **model_kwargs,
) -> tuple[OutputType, float, int, int, dict]:
    _setup_hf_client()
    filtered_kwargs: dict = select_values(notnone, model_kwargs)  # type: ignore

    messages = opt_messages_to_list(system_message, user_message, convert_system_to_user=convert_system_to_user)

    if func_spec is not None:
        messages[-1]["content"] += (f"\nRespond as if you were a function named {func_spec.name} that was given the "
                                    f"text above as argument, and following the "
                                    f"format\n{func_spec.json_schema}\n{func_spec.description}. Ensure the response is "
                                    f"loadable using json.loads")

    t0 = time.time()
    completion = backoff_create(
        aux_llm_query,
        OPENAI_TIMEOUT_EXCEPTIONS,
        messages=messages,
        **filtered_kwargs,
    )

    req_time = time.time() - t0

    choice = completion.choices[0]
    output = None

    if func_spec is None:
        output = choice.message.content
    else:
        retries = 0
        output_string = choice.message.content
        while retries < max_retries:
            try:
                output = json.loads(fix_json_string(output_string))
                missing_keys, error_message = check_for_anomaly(output, func_spec.json_schema)
                if missing_keys:
                    error_message += f"\nFollowing keys {missing_keys} missing in {output_string}"
                if len(error_message):
                    raise ValueError(error_message)
                else:
                    break
            except Exception as e:
                # Log the error and save the problematic content to a file
                logger.error(f"Error decoding the function arguments: {output_string} {e}")
                os.makedirs("json_errors", exist_ok=True)
                with open(f"json_errors/json_error_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.txt", 'w') as f:
                    f.write(output_string)
                output_string = json_fix_query(
                    messages=messages, error=e, filtered_kwargs=filtered_kwargs
                )
                retries += 1

    in_tokens = completion.usage.prompt_tokens
    out_tokens = completion.usage.completion_tokens

    info = {
        "system_fingerprint": completion.system_fingerprint,
        "model": completion.model,
        "created": completion.created,
    }

    return output, req_time, in_tokens, out_tokens, info
