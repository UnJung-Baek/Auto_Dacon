import json
import logging
import os.path
from  pathlib import  Path
import random
import shutil
import time
from typing import Any, Callable, cast

import humanize

from .backend import FunctionSpec, query
from .backend import get_llm_connection_elapsed_time, reset_llm_connection_elapsed_time
from .interpreter import ExecutionResult
from .journal import Journal, Node
from .utils import data_preview
from .utils.config import Config
from .utils.db_retriever import get_relevant_documents
from .utils.metric import MetricValue, WorstMetricValue
from .utils.response import extract_code, extract_text_up_to_code, wrap_code

logger = logging.getLogger("aide")


def format_time(time_in_sec: int):
    return f"{time_in_sec // 3600}hrs {(time_in_sec % 3600) // 60}mins {int(time_in_sec % 60)}secs"


ExecCallbackType = Callable[[str, bool], ExecutionResult]

review_func_spec = FunctionSpec(
    name="submit_review",
    json_schema={
        "type": "object",
        "properties": {
            "is_bug": {
                "type": "boolean",
                "description": "true if the output log shows that the execution failed or has some bug, otherwise false.",
            },
            "has_csv_submission": {
                "type": "boolean",
                "description": "true if the code saves the predictions on the test data"
                               " in a `submission.csv` file in the `./submission/` directory, otherwise false."
                               " Note that the file MUST be saved in the ./submission/ directory for this to be evaluated as true."
                               " Otherwise, it should be evaluated as false."
                               " You can assume the ./submission/ directory exists and is writable.",
            },
            "summary": {
                "type": "string",
                "description": "write a short summary (2-3 sentences) describing "
                               " the empirical findings. Alternatively mention if there is a bug or"
                               " the submission.csv was not properly produced."
                               " DO NOT suggest fixes or improvements.",
            },
            "metric": {
                "type": "number",
                "description": "If the code ran successfully, report the value of the validation metric. Otherwise, leave it null.",
            },
            "lower_is_better": {
                "type": "boolean",
                "description": "true if the metric should be minimized (i.e. a lower metric value is better, such as with MSE), false if the metric should be maximized (i.e. a higher metric value is better, such as with accuracy).",
            },
        },
        "required": [
            "is_bug",
            "has_csv_submission",
            "summary",
            "metric",
            "lower_is_better",
        ],
    },
    description="Submit a review evaluating the output of the training script.",
)


class Agent:
    def __init__(
            self,
            task_desc: str,
            cfg: Config,
            journal: Journal,
    ):
        super().__init__()
        self.task_desc = task_desc
        self.cfg = cfg
        self.acfg = cfg.agent
        self.journal = journal
        self.data_preview: str | None = None
        self.start_time = time.time()
        self.hf_time_file = os.path.join(self.cfg.workspace_dir, "hf_retries.json")
        if self.acfg.use_rag:
            rag_path = self.acfg.rag_path
            if rag_path is None:
                raise FileNotFoundError("RAG Database path cannot be None")
            rag_db_path = Path(rag_path) / "kaggle_db"
            if not rag_db_path.exists():
                raise FileNotFoundError("RAG database does not exists")
            elif not rag_db_path.is_absolute():
                rag_db_path = Path.cwd() / rag_path / "kaggle_db"

            self.retrieved_docs = get_relevant_documents(
                task_desc=self.task_desc,
                exp_name=self.cfg.exp_name,
                search_k=self.acfg.search.num_drafts,
                rag_path=str(rag_db_path),
                timeout=1000
            )

    @property
    def current_step(self) -> int:
        return len(self.journal)

    @property
    def time_limit(self) -> int:
        hf_time = get_llm_connection_elapsed_time(model=self.acfg.code.model)
        if hf_time:
            time_wasted = {}
            if os.path.exists(self.hf_time_file):
                with open(self.hf_time_file, 'r') as f:
                    time_wasted = json.load(f)
            time_wasted.update({time.time(): hf_time})
            with open(self.hf_time_file, 'w') as f:
                json.dump(time_wasted, f, indent=4)

        reset_llm_connection_elapsed_time(model=self.acfg.code.model)
        self.acfg.time_limit += hf_time
        return self.acfg.time_limit

    def search_policy(self) -> Node | None:
        """Select a node to work on (or None to draft a new node)."""
        search_cfg = self.acfg.search

        # initial drafting
        if len(self.journal.draft_nodes) < search_cfg.num_drafts:
            logger.info("[search policy] drafting new node (not enough drafts)")
            return None

        # debugging
        if random.random() < search_cfg.debug_prob:
            # nodes that are buggy + leaf nodes + debug depth < max debug depth
            debuggable_nodes = [
                n
                for n in self.journal.buggy_nodes
                if (n.is_leaf and n.debug_depth <= search_cfg.max_debug_depth)
            ]
            if debuggable_nodes:
                node_to_debug = random.choice(debuggable_nodes)
                logger.info(f"[search policy] debugging node {node_to_debug.id}")
                return node_to_debug

        # back to drafting if no nodes to improve
        good_nodes = self.journal.good_nodes
        if not good_nodes:
            logger.info("[search policy] drafting new node (no good nodes)")
            return None

        # greedy
        greedy_node = self.journal.get_best_node()
        logger.info(f"[search policy] greedy node selected: node {greedy_node.id}")
        return greedy_node

    @property
    def _prompt_environment(self):
        pkgs = [
            "numpy",
            "pandas",
            "scikit-learn",
            "statsmodels",
            "xgboost",
            "lightGBM",
            "torch",
            "torchvision",
            "torch-geometric",
            "bayesian-optimization",
            "timm",
        ]
        random.shuffle(pkgs)
        pkg_str = ", ".join([f"`{p}`" for p in pkgs])

        env_prompt = {
            "Installed Packages": f"Your solution can use any relevant machine learning packages such as: {pkg_str}. Feel free to use any other packages too (all packages are already installed!). For neural networks we suggest using PyTorch rather than TensorFlow."
        }
        return env_prompt

    @property
    def _prompt_impl_guideline(self):
        tot_time_elapsed = time.time() - self.start_time
        tot_time_remaining = self.acfg.time_limit - tot_time_elapsed
        exec_timeout = int(min(self.cfg.exec.timeout, tot_time_remaining))

        impl_guideline = [
            f"<TOTAL_TIME_REMAINING: {format_time(tot_time_remaining)}>",
            f"<TOTAL_STEPS_REMAINING: {self.acfg.steps - self.current_step}>",
            "The code should **implement the proposed solution**, **print the value of the evaluation metric computed on a hold-out validation set**,",
            "**AND MOST IMPORTANTLY SAVE PREDICTIONS ON THE PROVIDED UNLABELED TEST DATA IN A `submission.csv` FILE IN THE ./submission/ DIRECTORY.**",
            "The code should be a single-file python program that is self-contained and can be executed as-is.",
            "No parts of the code should be skipped, don't terminate the before finishing the script.",
            "Your response should only contain a single code block.",
            f"Be aware of the running time of the code, it should complete within {humanize.naturaldelta(exec_timeout)}.",
            'Do not copy data to workspace, read data from the source specified.',
            'You can use the "./working" directory to store any temporary files that your code needs to create.',
        ]
        if self.acfg.expose_prediction:
            impl_guideline.append(
                "The implementation should include a predict() function, "
                "allowing users to seamlessly reuse the code to make predictions on new data. "
                "The prediction function should be well-documented, especially the function signature."
            )

        if self.acfg.k_fold_validation > 1:
            impl_guideline.append(
                f"The evaluation should be based on {self.acfg.k_fold_validation}-fold cross-validation but only if that's an appropriate evaluation for the task at hand."
            )

        return {"Implementation guideline": impl_guideline}

    @property
    def _prompt_resp_fmt(self):
        return {
            "Response format": (
                "Your response should be a brief outline/sketch of your proposed solution in natural language (3-5 sentences), "
                "followed by a single markdown code block (wrapped in ```) which implements this solution and prints out the evaluation metric. "
                "There should be no additional headings or text in your response. Just natural language text followed by a newline and then the markdown code block. "
            )
        }

    def plan_and_code_query(self, prompt, retries=3) -> tuple[str, str]:
        """Generate a natural language plan + code in the same LLM call and split them apart."""
        completion_text = None
        for _ in range(retries):
            completion_text = query(
                system_message=prompt,
                user_message=None,
                model=self.acfg.code.model,
                temperature=self.acfg.code.temp,
                convert_system_to_user=self.acfg.convert_system_to_user,
            )

            code = extract_code(completion_text)
            nl_text = extract_text_up_to_code(completion_text)

            if code and nl_text:
                # merge all code blocks into a single string
                return nl_text, code

            logger.info("Plan + code extraction failed, retrying...")
        logger.info("Final plan + code extraction attempt failed, giving up...")
        return "", completion_text  # type: ignore

    def format_retrieved_context(self, docs):
        formatted = []
        for doc in docs:
            description, score, competition = doc
            formatted.append(f"- Description: {description}\n  Similarity Score: {score:.2f}")
        return "\n\n".join(formatted)

    def _draft(self) -> Node:
        if self.acfg.use_rag:
            if len(self.retrieved_docs) == 0:
                raise ValueError("There is no cases retrieved yet.")
            retrieved_context, score, competition = self.retrieved_docs[len(self.journal.draft_nodes) % self.acfg.search.num_drafts]
            logger.info(f'Retrieved reference competition: {competition}')

        introduction = (
            "You are a Kaggle grandmaster attending a competition. "
            "In order to win this competition, you need to come up with an excellent and creative plan "
            "for a solution and then implement this solution in Python. We will now provide a description of the task."
        )
        if self.acfg.obfuscate:
            introduction = (
                "You are an expert machine learning engineer attempting a task. "
                "In order to complete this task, you need to come up with an excellent and creative plan "
                "for a solution and then implement this solution in Python. We will now provide a description of the task."
            )
        if self.acfg.use_rag:
            prompt: Any = {
                "Introduction": introduction,
                "Task description": self.task_desc,
                "Here is a few past experience cases written by an human expert for a relevant (but not the same) task": retrieved_context,
                "Memory": self.journal.generate_summary(),
                "Instructions": {},
            }
            prompt["Instructions"] |= self._prompt_resp_fmt
            prompt["Instructions"] |= {
                "Solution sketch guideline": [
                    "Carefully examine the past solutions. These solutions may not be identical to the task at hand, but they provide valuable insights on strategies and techniques.",
                    "Look for common strategies that led to success, such as specific modeling techniques, evaluation metrics, or feature engineering methods.",
                    "Incorporate the lessons learned from these solutions into your proposed solution, making sure to adapt them to the current task.",
                    "The solutions should inform how to approach the current task, focusing on critical decisions made in those examples and any relevant best practices.",
                    "Do not copy the solutions verbatim, but leverage them as a foundation for crafting a novel, efficient, and creative approach.",
                    "You are encouraged to explore new angles while respecting the context and recommendations from the previous successful strategies.",
                    "Take the Memory section into consideration when proposing the design",
                    "don't propose the same modelling solution but keep the evaluation the same.",
                    "The solution sketch should be 3-5 sentences.",
                    "Propose an evaluation metric that is reasonable for this task.",
                    "Don't suggest to do EDA.",
                ],
            }
        else:
            prompt: Any = {
                "Introduction": introduction,
                "Task description": self.task_desc,
                "Memory": self.journal.generate_summary(),
                "Instructions": {},
            }
            prompt["Instructions"] |= self._prompt_resp_fmt
            prompt["Instructions"] |= {
                "Solution sketch guideline": [
                    "This first solution design should be relatively simple, without ensembling or hyper-parameter optimization.",
                    "Take the Memory section into consideration when proposing the design,"
                    " don't propose the same modelling solution but keep the evaluation the same.",
                    "The solution sketch should be 3-5 sentences.",
                    "Propose an evaluation metric that is reasonable for this task.",
                    "Don't suggest to do EDA.",
                ],
            }

        prompt["Instructions"] |= self._prompt_impl_guideline
        prompt["Instructions"] |= self._prompt_environment

        if self.acfg.data_preview:
            prompt["Data Overview"] = self.data_preview

        if self.acfg.use_agent_k_warm_start and self.acfg.agent_k_submissions is not None:
            if os.path.exists(self.acfg.agent_k_submissions):
                with open(self.acfg.agent_k_submissions, "r") as f:
                    agent_k_submissions = f.read()
                prompt["Summary of Past Submissions"] = agent_k_submissions

        plan, code = self.plan_and_code_query(prompt)
        new_node = Node(plan=plan, code=code)
        logger.info(f"Drafted new node {new_node.id}")
        return new_node

    def _improve(self, parent_node: Node) -> Node:
        introduction = (
            "You are a Kaggle grandmaster attending a competition. You are provided with a previously developed "
            "solution below and should improve it in order to further increase the (test time) performance. "
            "For this you should first outline a brief plan in natural language for how the solution can be improved and "
            "then implement this improvement in Python based on the provided previous solution. "
        )
        if self.acfg.obfuscate:
            introduction = (
                "You are an expert machine learning engineer attempting a task. You are provided with a previously developed "
                "solution below and should improve it in order to further increase the (test time) performance. "
                "For this you should first outline a brief plan in natural language for how the solution can be improved and "
                "then implement this improvement in Python based on the provided previous solution. "
            )
        prompt: Any = {
            "Introduction": introduction,
            "Task description": self.task_desc,
            "Memory": self.journal.generate_summary(),
            "Instructions": {},
        }
        prompt["Previous solution"] = {
            "Code": wrap_code(parent_node.code),
        }

        prompt["Instructions"] |= self._prompt_resp_fmt
        prompt["Instructions"] |= {
            "Solution improvement sketch guideline": [
                "The solution sketch should be a brief natural language description of how the previous solution can be improved.",
                "You should be very specific and should only propose a single actionable improvement.",
                "This improvement should be atomic so that we can experimentally evaluate the effect of the proposed change.",
                "Take the Memory section into consideration when proposing the improvement.",
                "The solution sketch should be 3-5 sentences.",
                "Don't suggest to do EDA.",
            ],
        }
        prompt["Instructions"] |= self._prompt_impl_guideline

        plan, code = self.plan_and_code_query(prompt)
        new_node = Node(plan=plan, code=code, parent=parent_node)
        logger.info(f"Improved node {parent_node.id} to create new node {new_node.id}")
        return new_node

    def _debug(self, parent_node: Node) -> Node:
        introduction = (
            "You are a Kaggle grandmaster attending a competition. "
            "Your previous solution had a bug and/or did not produce a submission.csv, "
            "so based on the information below, you should revise it in order to fix this. "
            "Your response should be an implementation outline in natural language,"
            " followed by a single markdown code block which implements the bugfix/solution."
        )
        if self.acfg.obfuscate:
            introduction = (
                "You are an expert machine learning engineer attempting a task. "
                "Your previous solution had a bug and/or did not produce a submission.csv, "
                "so based on the information below, you should revise it in order to fix this. "
                "Your response should be an implementation outline in natural language,"
                " followed by a single markdown code block which implements the bugfix/solution."
            )
        prompt: Any = {
            "Introduction": introduction,
            "Task description": self.task_desc,
            "Previous (buggy) implementation": wrap_code(parent_node.code),
            "Execution output": wrap_code(parent_node.term_out, lang=""),
            "Instructions": {},
        }
        prompt["Instructions"] |= self._prompt_resp_fmt
        prompt["Instructions"] |= {
            "Bugfix improvement sketch guideline": [
                "You should write a brief natural language description (3-5 sentences) of how the issue in the previous implementation can be fixed.",
                "Don't suggest to do EDA.",
            ],
        }
        prompt["Instructions"] |= self._prompt_impl_guideline

        if self.acfg.data_preview:
            prompt["COMPETITION INSTRUCTION"] = self.data_preview

        plan, code = self.plan_and_code_query(prompt)
        new_node = Node(plan=plan, code=code, parent=parent_node)
        logger.info(f"Debugged node {parent_node.id} to create new node {new_node.id}")
        return new_node

    def update_data_preview(
            self,
    ):
        self.data_preview = data_preview.generate(self.cfg.data_dir, simple=True)

    def copy_submission_file(self, submission_path, all_submissions_dir):
        submission_path = self.cfg.workspace_dir / "submission" / "submission.csv"
        all_submissions_dir = self.cfg.workspace_dir / "all_submissions"

        all_submissions_dir.mkdir(exist_ok=True)

        # Check for existing files and determine a unique name
        file_name = "submission.csv"
        base_name, ext = file_name.rsplit(".", 1)
        counter = 1

        while (all_submissions_dir / file_name).exists():
            file_name = f"{base_name}_{counter}.{ext}"
            counter += 1

        # Copy the file with the unique name
        shutil.copy(submission_path, all_submissions_dir / file_name)

    def remove_non_existing_best_submission(
            self, best_node_ids: list, best_solution_dir: Path, best_submission_dir: Path
    ) -> None:

        # Remove non-existing solution directories in top N best solutions
        for solution_dir in best_solution_dir.iterdir():
            if solution_dir.is_dir():
                solution_node_id = solution_dir.name.split('_')[-1]
                if solution_node_id not in best_node_ids:
                    print(f"Deleting non-matching solution directory: {solution_dir}")
                    try:
                        shutil.rmtree(solution_dir)
                    except Exception as e:
                        print(f"Error while deleting directory {solution_dir}: {e}")

        # Remove non-existing submission CSV files in top N best solutions
        for submission_file in best_submission_dir.iterdir():
            if submission_file.is_file():
                submission_node_id = submission_file.name.split('_')[-1].split('.')[0]
                if submission_node_id not in best_node_ids:
                    print(f"Deleting non-matching submission file: {submission_file}")
                    try:
                        submission_file.unlink()
                    except Exception as e:
                        print(f"Error while deleting file {submission_file}: {e}")

    def step(self, exec_callback: ExecCallbackType):
        # save previous submission file and clear the submission dir from previous steps
        # if (self.cfg.workspace_dir / "submission" / "submission.csv").exists():
        # self.copy_submission_file((self.cfg.workspace_dir / "submission" / "submission.csv"),
        #                           (self.cfg.workspace_dir / "all_submissions"))
        submission_dir = self.cfg.workspace_dir / "submission"
        shutil.rmtree(submission_dir, ignore_errors=True)
        best_submissions_dir = self.cfg.workspace_dir / "best_submissions"
        intermediate_best_submissions_dir = self.cfg.workspace_dir / "intermediate_best_submissions"
        draft_submissions_dir = self.cfg.workspace_dir / "draft_submissions"
        submission_dir.mkdir(exist_ok=True)
        best_submissions_dir.mkdir(exist_ok=True)
        intermediate_best_submissions_dir.mkdir(exist_ok=True)
        draft_submissions_dir.mkdir(exist_ok=True)

        if not self.journal.nodes or self.data_preview is None:
            self.update_data_preview()

        parent_node = self.search_policy()
        logger.info(f"Agent is generating code, parent node type: {type(parent_node)}")

        if parent_node is None:
            result_node = self._draft()
        elif parent_node.is_buggy:
            result_node = self._debug(parent_node)
        else:
            result_node = self._improve(parent_node)

        result_node = self.parse_exec_result(
            node=result_node,
            exec_result=exec_callback(result_node.code, True),
        )
        # handle final cases where we missed buggy nodes somehow
        if not result_node.is_buggy:
            if not (submission_dir / "submission.csv").exists():
                result_node.is_buggy = True
                result_node.metric = WorstMetricValue()
                logger.info(
                    f"Actually, node {result_node.id} did not produce a submission.csv"
                )
        self.journal.append(result_node)

        # to save draft node submission.csv for later analysis
        if result_node.is_draft:
            shutil.copyfile(
                src=submission_dir / "submission.csv",
                dst=draft_submissions_dir / f"submission_{result_node.id}.csv"
            )

        # if the result_node is the best node, cache its submission.csv and solution.py
        # to best_solution/ by copying it there
        best_nodes = self.journal.get_top_n_nodes(n=self.cfg.top_n)
        best_nodes_ids = [best_node.id for best_node in best_nodes]
        if result_node.id in best_nodes_ids:
            logger.info(f"Node {result_node.id} is added to best nodes")
            best_solution_dir = self.cfg.workspace_dir / "best_solutions" / f"solution_{result_node.id}"
            best_solution_dir.mkdir(exist_ok=True, parents=True)

            # Copy submission/submission.csv to best_submission/submission.csv
            shutil.copy(
                submission_dir / "submission.csv",
                best_submissions_dir / f"submission_{result_node.id}.csv",
            )
            # add current node to intermediate_best_submissions for post-processing
            shutil.copy(
                submission_dir / "submission.csv",
                intermediate_best_submissions_dir / f"submission_{result_node.id}.csv",
            )
            # Copy solution.py and relevant node id to best_solution/
            with open(best_solution_dir / "solution.py", "w") as f:
                f.write(result_node.code)
            # Take note of the node id of the best nodes
            with open(best_solution_dir / "node_id.txt", "w") as f:
                f.write(str(result_node.id))

            self.remove_non_existing_best_submission(
                best_node_ids=best_nodes_ids,
                best_solution_dir=self.cfg.workspace_dir / "best_solutions",
                best_submission_dir=best_submissions_dir
            )
            best_gen_time_file_path = Path(self.cfg.workspace_dir, self.acfg.best_gen_time_file)
            with open(best_gen_time_file_path, "w") as f:
                f.write(str(time.time()))

            # record time since start of run for post-processing intermediate best submissions
            remaining_time = self.time_limit - (time.time() - self.start_time)
            remaining_time_dict = {
                f"submission_{result_node.id}.csv": remaining_time,
            }
            remaining_time_json_path = intermediate_best_submissions_dir / "remaining_time.json"
            if (remaining_time_json_path).exists():
                with open(remaining_time_json_path, "r") as f:
                    time_since_run_start_json = json.load(f)
                time_since_run_start_json.update(remaining_time_dict)
            else:
                time_since_run_start_json = remaining_time_dict
            with open(remaining_time_json_path, "w") as f:
                json.dump(time_since_run_start_json, f)

        else:
            logger.info(f"Node {result_node.id} is not added to best nodes")
            logger.info(f"Nodes {best_nodes_ids} are still the best nodes")

    def parse_exec_result(self, node: Node, exec_result: ExecutionResult) -> Node:
        logger.info(f"Agent is parsing execution results for node {node.id}")

        node.absorb_exec_result(exec_result)

        introduction = (
            "You are a Kaggle grandmaster attending a competition. "
            "You have written code to solve this task and now need to evaluate the output of the code execution. "
            "You should determine if there were any bugs as well as report the empirical findings."
        )
        if self.acfg.obfuscate:
            introduction = (
                "You are an expert machine learning engineer attempting a task. "
                "You have written code to solve this task and now need to evaluate the output of the code execution. "
                "You should determine if there were any bugs as well as report the empirical findings."
            )
        prompt = {
            "Introduction": introduction,
            "Task description": self.task_desc,
            "Implementation": wrap_code(node.code),
            "Execution output": wrap_code(node.term_out, lang=""),
        }

        raw_response = query(
            system_message=prompt,
            user_message=None,
            func_spec=review_func_spec,
            model=self.acfg.feedback.model,
            temperature=self.acfg.feedback.temp,
            convert_system_to_user=self.acfg.convert_system_to_user,
        )
        response = cast(
            dict,
            raw_response
        )

        # if the metric isn't a float then fill the metric with the worst metric
        if not isinstance(response["metric"], float):
            response["metric"] = None

        # do an extra check, to catch cases where judge fails
        has_csv_submission = (
                self.cfg.workspace_dir / "submission" / "submission.csv"
        ).exists()

        node.analysis = response["summary"]
        node.is_buggy = (
                response["is_bug"]
                or node.exc_type is not None
                or response["metric"] is None
                or response["has_csv_submission"] == False
                or has_csv_submission == False
        )

        if node.is_buggy:
            logger.info(
                f"Parsed results: Node {node.id} is buggy and/or did not produce a submission.csv"
            )
            node.metric = WorstMetricValue()
        else:
            logger.info(f"Parsed results: Node {node.id} is not buggy")
            node.metric = MetricValue(
                response["metric"], maximize=not response["lower_is_better"]
            )

        return node
